//json = javascript object notation
const mensch = {
    "name":"oliver",
    "hobby":"segeln"
}

//parse wnadelt json in javascript um
let obj. JSON.parse(mensch);

//javascriptObjekt
const mensch = {
    name:'oliver',
    hobby:'segeln'
}

obj.hobby _> segeln

