<?xml version="1.0" encoding="utf-8"?>
<sammlung>
    <fahrzeug>
        <farbe>rot</farbe>
        <speed>120</speed>
        <leistung hubraum="1600" zylinder="4">140ps</leistung>
    </fahrzeug>

    <fahrzeug>
        <farbe>rot</farbe>
        <speed>120</speed>
        <leistung hubraum="1600" zylinder="4">140ps</leistung>
    </fahrzeug>
</sammlung>

x[i].getElementsByTagName("fahrzeug")[0].childNodes[0].nodeValue;

fahrzeug.farbe